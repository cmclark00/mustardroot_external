/opt/muos/device/current/script/led_control.sh 1 76 225 173 1 225 173 1
